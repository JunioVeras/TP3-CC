#!/bin/bash

cd /tmp
streamlit run plotter.py --server.port 7000