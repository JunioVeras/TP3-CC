import os
import re
import sys
from typing import Any

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from minha_func import executaAlgo


def handler1(input: dict, context: object) -> dict[str, Any]:
    metrics = {}

    metrics["percent-network-egress"] = input["net_io_counters_eth0-bytes_sent"]
    metrics["percent-memory-cache"] = input["virtual_memory-total"]

    regex = re.compile(r"^cpu_percent-\d+")
    matching_fields = [field for field in input.keys() if regex.match(field)]

    persisted = context.env
    if persisted == {}:
        for field in matching_fields:
            persisted[field] = 0

    for field in matching_fields:
        metrics["avg_" + field] = persisted[field] + 1
        persisted[field] += 1

    print(executaAlgo(1, "aa"))

    context.env = persisted
    return metrics


def handler2(input: dict, context: object) -> dict[str, Any]:
    metrics = {}

    metrics["percent-network-egress"] = (
        input["net_io_counters_eth0-bytes_sent"] / 100000
    )
    metrics["percent-memory-cache"] = input["virtual_memory-total"] / 100000

    regex = re.compile(r"^cpu_percent-\d+")
    matching_fields = [field for field in input.keys() if regex.match(field)]

    persisted = context.env
    if persisted == {}:
        for field in matching_fields:
            persisted[field] = 0

    for field in matching_fields:
        metrics["avg_" + field] = persisted[field] - 1
        persisted[field] -= 1

    print(executaAlgo(4, "aa"))

    context.env = persisted
    return metrics
