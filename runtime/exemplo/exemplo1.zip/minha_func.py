def executaAlgo(a: int, b: str):
    return f"b: {a + 1}"
