import streamlit as st
import redis
import json
import matplotlib.pyplot as plt
import pandas as pd
import time
import os


# Connect to Redis
def get_redis_connection():
    return redis.Redis(host=os.environ["REDIS_HOST"], port=6379, decode_responses=True)


# Fetch data from Redis
def fetch_data_from_redis(redis_conn, key):
    data = redis_conn.get(key)
    if data:
        return json.loads(data)  # Parse JSON data
    return None


# Plot data over time
def plot_accumulated_metrics(accumulated_data, metric_limit):
    if not accumulated_data:
        st.warning("No data to plot yet.")
        return

    df = pd.DataFrame(accumulated_data)

    st.write("### Cache Usage")
    cpu_metrics = df.filter(like="percent-memory-cache")
    fig, ax = plt.subplots()
    ax.plot(
        cpu_metrics.index,
        cpu_metrics["percent-memory-cache"],
        label="percent-memory-cache",
    )
    ax.set_xlabel("Time")
    ax.set_ylabel("Cache Usage (%)")
    ax.legend()
    ax.grid()
    st.pyplot(fig)
    plt.close()

    st.write("### Network Egress")
    cpu_metrics = df.filter(like="percent-network-egress")
    fig, ax = plt.subplots()
    ax.plot(
        cpu_metrics.index,
        cpu_metrics["percent-network-egress"],
        label="percent-network-egress",
    )
    ax.set_xlabel("Time")
    ax.set_ylabel("Network Egress (%)")
    ax.legend()
    ax.grid()
    st.pyplot(fig)
    plt.close()

    # # Other metrics in the second column
    st.write("### CPU's usages")

    # Plot each metric
    other_metrics = df.drop(columns=["percent-memory-cache", "percent-network-egress"])
    fig, ax = plt.subplots(figsize=(12, 6))
    for column in other_metrics.columns:
        ax.plot(other_metrics.index, other_metrics[column], label=column)

    ax.set_title("CPU usage moving average")
    ax.set_xlabel("Time (Seconds)")
    ax.set_ylabel("CPU usage (%)")
    ax.legend(loc="upper left")
    st.pyplot(fig)
    plt.close()


# Streamlit app
def main():
    st.title("Real-Time Accumulated Metrics Visualization")
    redis_conn = get_redis_connection()

    key = st.text_input("Enter the Redis key for the data:", "metrics_key")
    refresh_rate = st.slider("Refresh rate (seconds):", 1, 10, 2)
    metric_limit = st.slider("Number of data points to display:", 10, 100, 50)

    if st.button("Start Visualization"):
        st.write("Fetching data and updating metrics...")
        placeholder = st.empty()
        accumulated_data = []

        while True:
            data = fetch_data_from_redis(redis_conn, key)
            if data:
                # Append the new data point
                accumulated_data.append(data)
                if len(accumulated_data) > metric_limit:
                    accumulated_data = accumulated_data[-metric_limit:-1]

                # Use the placeholder for real-time updates
                with placeholder.container():
                    st.subheader("Latest Metrics")
                    st.json(data)

                    st.subheader("Metrics Visualization")
                    plot_accumulated_metrics(accumulated_data, metric_limit)
            else:
                st.error(f"No data found for key: {key}")

            time.sleep(refresh_rate)


if __name__ == "__main__":
    main()
